let provincias = document.querySelector('#provincias');

provincias.addEventListener('change', cargarSelector);


function cargarSelector(event) {
    console.log(event.target.value);

    let url = "http://sitelicon.eu/test/ajax_localidades.php?id=" + event.target.value;

    let peticion = new XMLHttpRequest();
    peticion.open('GET', url, true);

    peticion.setRequestHeader('Access-Control-Allow-Origin', '*');
    peticion.send();

    peticion.addEventListener('load', function (event) {
        console.log(event.target)
    })

}